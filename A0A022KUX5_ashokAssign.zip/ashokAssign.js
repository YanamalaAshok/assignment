function plotGraph() {
    var inputValue1 = parseInt(document.getElementById("inputValue").value);
    var maxValue1 = parseInt(document.getElementById("maxValue").value);
    var graphBarId = document.getElementById("graphBar");
    var graphBarParaId = document.getElementById("graphBarPara");
    var pieChartParaId = document.getElementById("pieChartPara");
    var graphBarId1 = document.getElementById("graphBar1");
    var graphBarParaId1 = document.getElementById("graphBarPara1");
    if (isNaN(inputValue1) || isNaN(maxValue1)) {
        alert("Please enter numeric values.");
        return;
    }

    if (inputValue1 > maxValue1) {
        alert("Input value cannot be greater than max value.");
        return;
    }

    var percentage = (inputValue1 / maxValue1) * 100;

    graphBarId.style.height = percentage + "%";
    graphBarParaId.textContent = Math.floor(percentage) + "%";

    var pieChart = document.getElementById("my-pie-chart");
    pieChart.style.background = "conic-gradient(blue " + percentage + "%, white " + Math.ceil(100 - percentage) + "%)";
    pieChartParaId.textContent = Math.floor(percentage) + "%";

    graphBarId1.style.height = percentage + "%";
    graphBarParaId1.textContent = Math.floor(percentage) + "%";
}